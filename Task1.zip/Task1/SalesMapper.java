package tvsales;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

public class SalesMapper extends MapReduceBase implements
		Mapper<LongWritable, Text, Text, IntWritable> {
	private final static IntWritable one = new IntWritable(1);
	private final static String NOT_AVAILABLE = "NA";
	//private final static String Onida = "Onida";

	public void map(LongWritable key, Text value,
			OutputCollector<Text, IntWritable> output, Reporter reporter)
			throws IOException {
		String valueString = value.toString();
		String[] SingleCountryData = valueString.split("\\|");
		if((SingleCountryData[0].equals(NOT_AVAILABLE)) || (SingleCountryData[1].equals(NOT_AVAILABLE)))
		{
		output.collect(new Text(value), one);
		}
	}
}